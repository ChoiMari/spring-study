package DI_04_Spring;

public interface MessageBean {
	void sayHello();
}
