package DI_06_Spring;

/*
  DB 테이블과 1:1 클래스
  create table Article
  컬럼   >> member field

*/
public class Article {
	//member field 구현
	//생성자 구현
	//setter , getter  구현
	//toString() 재정의
	
	//롬복 @DATA
}
