package DI_03_Spring;

public interface MessageBean {
	void sayHello(String name);
}
