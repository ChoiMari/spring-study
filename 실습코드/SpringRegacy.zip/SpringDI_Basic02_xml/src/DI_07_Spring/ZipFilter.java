package DI_07_Spring;

public class ZipFilter  implements MyFilter{

}
