package DI_07_Spring;

public class EncFilter  implements MyFilter{

}
