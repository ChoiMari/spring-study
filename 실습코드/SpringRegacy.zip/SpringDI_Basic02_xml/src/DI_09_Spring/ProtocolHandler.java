package DI_09_Spring;

public interface ProtocolHandler {

}
