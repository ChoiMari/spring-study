package DI_09_Spring;

public class RestHandler implements ProtocolHandler {

}
