package DI_09_Spring;

public class RssHandler implements ProtocolHandler {

}
