package DI_08_Spring;

public class ArticleDao {

}
