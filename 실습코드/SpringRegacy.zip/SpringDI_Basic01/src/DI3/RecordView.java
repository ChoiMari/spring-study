package DI3;

public interface RecordView {
	void print();
	void input();
}
