package DI;

public class Program {

	public static void main(String[] args) {
		NewRecordView view = new NewRecordView(100, 50, 40);
		view.print();
	}

}
