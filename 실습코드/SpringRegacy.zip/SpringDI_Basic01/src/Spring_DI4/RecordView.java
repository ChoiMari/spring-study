package Spring_DI4;

public interface RecordView {
	void print();
	void input();
}
