package Spring_DI4;

public interface Record {
	int total();
	float avg();
}
